import joblib
from sklearn.ensemble import RandomForestRegressor
from xgboost import XGBRegressor
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from preprocess import preprocess_data

# Load and preprocess the data
X, y = preprocess_data(r"C:\Users\PC\Desktop\Student Performance Prediction System\Students_Grading_Dataset.csv")

# Split data into training, validation, and testing sets
X_train, X_temp, y_train, y_temp = train_test_split(X, y, test_size=0.2, random_state=42)
X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=0.5, random_state=42)

print("Training set size:", len(X_train))
print("Validation set size:", len(X_val))
print("Testing set size:", len(X_test))

# Train Random Forest Regressor model
random_forest_model = RandomForestRegressor(random_state=42)
random_forest_model.fit(X_train, y_train)
print("Random Forest Regressor trained.")

# Train XGBoost Regressor model
xgboost_model = XGBRegressor(random_state=42)
xgboost_model.fit(X_train, y_train)
print("XGBoost Regressor trained.")

# Train Neural Network Regressor model
neural_network_model = Sequential([
    Dense(64, activation='relu', input_shape=(X_train.shape[1],)),
    Dense(32, activation='relu'),
    Dense(1)  # No activation function for regression output
])

neural_network_model.compile(optimizer='adam', loss='mean_squared_error', metrics=['mean_absolute_error'])
neural_network_model.fit(X_train, y_train, epochs=10, validation_data=(X_val, y_val), verbose=0)
print("Neural Network Regressor trained.")

# Evaluate Random Forest Regressor
y_pred_rf = random_forest_model.predict(X_val)
mse_rf = mean_squared_error(y_val, y_pred_rf)
r2_rf = r2_score(y_val, y_pred_rf)
print(f"Random Forest Regressor MSE: {mse_rf:.2f}")
print(f"Random Forest Regressor R2 Score: {r2_rf:.2f}")

# Evaluate XGBoost Regressor
y_pred_xgb = xgboost_model.predict(X_val)
mse_xgb = mean_squared_error(y_val, y_pred_xgb)
r2_xgb = r2_score(y_val, y_pred_xgb)
print(f"XGBoost Regressor MSE: {mse_xgb:.2f}")
print(f"XGBoost Regressor R2 Score: {r2_xgb:.2f}")

# Evaluate Neural Network Regressor
y_pred_nn = neural_network_model.predict(X_val)
mse_nn = mean_squared_error(y_val, y_pred_nn)
r2_nn = r2_score(y_val, y_pred_nn)
print(f"Neural Network Regressor MSE: {mse_nn:.2f}")
print(f"Neural Network Regressor R2 Score: {r2_nn:.2f}")

# Select the best model based on validation results
best_model = min([(random_forest_model, mse_rf), (xgboost_model, mse_xgb), (neural_network_model, mse_nn)], key=lambda x: x[1])[0]
print(f"\nBest Model: {best_model}")

# Test the best model on the testing set
y_pred_test = best_model.predict(X_test)
mse_test = mean_squared_error(y_test, y_pred_test)
r2_test = r2_score(y_test, y_pred_test)
print(f"Best Model Test MSE: {mse_test:.2f}")
print(f"Best Model Test R2 Score: {r2_test:.2f}")

# Save the best model
joblib.dump(best_model, 'best_model.pkl')
