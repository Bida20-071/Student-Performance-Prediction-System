from flask import Flask, request, jsonify, render_template, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
import os
import pickle  # For loading the machine learning model
import traceback # Import traceback for detailed error logging

# --- Configuration ---
# Initialize Flask app
app = Flask(__name__)

# Configure the SQLite database (stored as users.db file in project directory)
# Use an absolute path for robustness
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'users.db')
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'a_very_secret_key_fallback') # Use environment variable for production secret key

# Initialize SQLAlchemy and LoginManager
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'  # Redirect to login page if user not authenticated
login_manager.login_message_category = 'info' # Category for the default login required message

# --- Database Models ---
# Define User model for login credentials and roles
class User(UserMixin, db.Model):
    """Represents a user with login credentials and a role."""
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    role = db.Column(db.String(50), nullable=False)  # Can be 'student' or 'lecturer'

    def __repr__(self):
        return f'<User {self.username}>'

# Define StudentData model for tracking attendance and grades
class StudentData(db.Model):
    """Stores student specific data like attendance and grades."""
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.String(50), nullable=False) # Link to the username in the User table (implicitly)
    attendance = db.Column(db.Float, nullable=False)
    grade = db.Column(db.String(2), nullable=False) # Assuming grades are like 'A+', 'B-', 'C' etc.

    def __repr__(self):
        return f'<StudentData {self.student_id}>'

# --- Flask-Login User Loader ---
@login_manager.user_loader
def load_user(user_id):
    """Loads a user from the database for Flask-Login."""
    try:
        return User.query.get(int(user_id))
    except (TypeError, ValueError):
        return None # Handle cases where user_id is invalid

# Machine Learning Model Loading
# Load the trained ML model from file
# Ensure the model file exists
model_path = 'best_model.pkl'
if os.path.exists(model_path):
    try:
        with open(model_path, 'rb') as f:
            model = pickle.load(f)
        print("Machine learning model loaded successfully.")
    except Exception as e:
        print(f"Error loading the machine learning model: {e}")
        model = None # Set model to None if loading fails
else:
    print(f"Machine learning model not found at {model_path}.")
    model = None # Set model to None if file does not exist

# --- Routes ---
# Homepage route
@app.route('/')
def home():
    """Renders the homepage."""
    return render_template('home.html')

# Registration route
@app.route('/register', methods=['GET', 'POST'])
def register():
    """Handles user registration."""
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        role = request.form.get('role')

        # Basic validation
        if not username or not password or not role:
            # In a real app, you'd provide feedback to the user
            print("Missing username, password, or role")
            return redirect(url_for('register')) # Redirect back to register page

        hashed_password = generate_password_hash(password, method='pbkdf2:sha256', salt_length=8)
        new_user = User(username=username, password=hashed_password, role=role)

        try:
            db.session.add(new_user)
            db.session.commit()
            print(f"User {username} registered successfully.")
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback() # Rollback in case of error
            print(f"Error during registration: {e}")
            # In a real app, handle specific errors like duplicate username
            return render_template('register.html', error="Registration failed. Username might already exist.")

    return render_template('register.html')

# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    """Handles user login."""
    if current_user.is_authenticated:
        # Redirect authenticated users based on role
        if current_user.role == 'student':
            return redirect(url_for('student_dashboard'))
        elif current_user.role == 'lecturer':
            return redirect(url_for('lecturer_dashboard'))
        else:
            # Handle unexpected roles
            logout_user()
            return redirect(url_for('login'))


    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        user = User.query.filter_by(username=username).first()

        if user and check_password_hash(user.password, password):
            login_user(user)
            print(f"User {username} logged in successfully.")
            # Redirect to the appropriate dashboard based on role
            if user.role == 'student':
                return redirect(url_for('student_dashboard'))
            elif user.role == 'lecturer':
                return redirect(url_for('lecturer_dashboard'))
            else:
                 # Handle unexpected roles after successful login
                logout_user()
                return redirect(url_for('login'))
        else:
            # In a real app, provide feedback to the user about invalid credentials
            print("Invalid username or password.")
            return render_template('login.html', error="Invalid username or password") # Pass error message to template

    return render_template('login.html')

# Logout route
@app.route('/logout')
@login_required
def logout():
    """Handles user logout."""
    logout_user()
    print("User logged out.")
    return redirect(url_for('login'))

# Student dashboard route
@app.route('/student_dashboard')
@login_required
def student_dashboard():
    """Renders the student dashboard."""
    if current_user.role == 'student':
        # Fetch data only for the logged-in student
        student_data = StudentData.query.filter_by(student_id=current_user.username).all()
        return render_template('student_dashboard.html', student_data=student_data)
    else:
        # Redirect non-student users
        print(f"Unauthorized access attempt to student dashboard by user {current_user.username} with role {current_user.role}.")
        return redirect(url_for('login'))

# Lecturer dashboard route
@app.route('/lecturer_dashboard')
@login_required
def lecturer_dashboard():
    """Renders the lecturer dashboard."""
    if current_user.role == 'lecturer':
        # Lecturer dashboard doesn't directly display StudentData on page load
        # Data is fetched via AJAX for charts and at-risk list
        return render_template('lecturer_dashboard.html')
    else:
        # Redirect non-lecturer users
        print(f"Unauthorized access attempt to lecturer dashboard by user {current_user.username} with role {current_user.role}.")
        return redirect(url_for('login'))

# Route for lecturers to enter grades and attendance
@app.route('/enter_grades', methods=['POST'])
@login_required
def enter_grades():
    """Handles lecturer input of grades and attendance."""
    if current_user.role != 'lecturer':
        print(f"Unauthorized attempt to enter grades by user {current_user.username} with role {current_user.role}.")
        return jsonify({'message': 'Unauthorized access'}), 403

    try:
        data = request.json
        student_id = data.get('student_id')
        attendance = data.get('attendance')
        grade = data.get('grade')

        # Basic input validation
        if not student_id or attendance is None or not grade:
             return jsonify({'message': 'Missing student ID, attendance, or grade'}), 400

        # Convert attendance to float, handle potential errors
        try:
            attendance = float(attendance)
            if not (0 <= attendance <= 100):
                 return jsonify({'message': 'Attendance must be between 0 and 100'}), 400
        except ValueError:
             return jsonify({'message': 'Invalid attendance value'}), 400


        new_entry = StudentData(student_id=student_id, attendance=attendance, grade=grade)

        db.session.add(new_entry)
        db.session.commit()

        print(f"Grades and attendance saved successfully for student {student_id}.")
        return jsonify({'message': 'Grades and attendance saved successfully'}), 200

    except Exception as e:
        db.session.rollback() # Rollback in case of error
        print(f"Error saving grades and attendance: {e}")
        traceback.print_exc() # Print detailed traceback to console
        return jsonify({'message': 'An error occurred while saving data.'}), 500


# Route to retrieve all student data (used for lecturer analytics)
@app.route('/get_student_data')
@login_required
def get_student_data():
    """Provides student data for lecturer analytics (charts, at-risk list)."""
    if current_user.role != 'lecturer':
        print(f"Unauthorized attempt to access student data by user {current_user.username} with role {current_user.role}.")
        return jsonify({'message': 'Unauthorized access'}), 403

    try:
        students = StudentData.query.all()

        # Prepare data for JSON response
        student_ids = [student.student_id for student in students]
        attendance = [student.attendance for student in students]
        grades_list = [student.grade for student in students] # Use a different name to avoid shadowing the function


        # Count the number of each grade
        grade_counts = {}
        for grade in grades_list:
            grade_counts[grade] = grade_counts.get(grade, 0) + 1

        # Define risk threshold and identify at-risk students by attendance
        # This threshold (50) seems low based on the report's mention of <60% or <50% grade.
        # Consider if this should align with the 70% used in student_dashboard.html for consistency
        at_risk_threshold_attendance = 60 # Or maybe 60 based on report?
        # The report also mentions grade < 50% as a risk factor.
        # Implementing grade-based risk flagging here would require parsing the grade string to a number, which might be complex depending on the grade format.
        # For now, sticking to the existing attendance-based risk flagging in this route's output.

        at_risk_students = [student.student_id for student in students if student.attendance < at_risk_threshold_attendance]

        return jsonify({
            'student_ids': student_ids,
            'attendance': attendance,
            'grades': list(grade_counts.keys()),
            'grade_counts': list(grade_counts.values()),
            'at_risk_students': at_risk_students
        })

    except Exception as e:
        print(f"Error retrieving student data: {e}")
        traceback.print_exc() # Print detailed traceback
        return jsonify({'message': 'An error occurred while retrieving data.'}), 500

# --- Main Execution ---
if __name__ == '__main__':
    # Create database tables if they don't exist within the application context
    with app.app_context():
        db.create_all()
        print("Database tables checked/created.")

    # Run the app
    # In a production environment, use a production-ready WSGI server
    app.run(debug=True) # Set debug=False in production
