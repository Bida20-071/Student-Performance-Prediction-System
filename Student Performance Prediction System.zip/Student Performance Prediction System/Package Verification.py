# List of packages to verify
packages = [
    'pandas',
    'sklearn',
    'xgboost',
    'tensorflow',
    'numpy',
    'matplotlib',
    'seaborn',
    'flask',
    'flask_sqlalchemy',
    'flask_login',
    'werkzeug',
    'joblib'
]

# Function to verify package installation
def verify_package(package):
    try:
        __import__(package)
        print(f"{package} installed successfully!")
    except ImportError:
        print(f"{package} is not installed. Please install it using pip.")

# Verify each package
for package in packages:
    verify_package(package)
