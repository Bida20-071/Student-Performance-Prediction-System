import pandas as pd
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer

def preprocess_data(csv_file):
    # Load the dataset
    data = pd.read_csv(csv_file)
    print("Data loaded successfully.")

    # Display the first few rows and the column names
    print(data.head())
    print(data.columns)

    # Identify and handle missing values in the dataset
    missing_values = data.isnull().sum()
    print("Missing values:\n", missing_values)

    # Fill missing values with the mean for numerical columns only
    numeric_features = data.select_dtypes(include=['number']).columns
    data[numeric_features] = data[numeric_features].fillna(data[numeric_features].mean())

    # Identify categorical features (if any)
    categorical_features = data.select_dtypes(include=['object']).columns.tolist()

    # Identify numerical features
    numerical_features = data.select_dtypes(exclude=['object']).columns.tolist()

    # Create a preprocessor for numerical and categorical features
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', StandardScaler(), numerical_features),
            ('cat', OneHotEncoder(handle_unknown='ignore', sparse_output=False), categorical_features)
        ],
        sparse_threshold=0  # Ensure the output is dense
    )

    # Fit and transform the data
    processed_features = preprocessor.fit_transform(data)

    # Get the feature names correctly
    numerical_feature_names = numerical_features  # Numerical feature names
    categorical_feature_names = preprocessor.named_transformers_['cat'].get_feature_names_out(categorical_features).tolist()
    feature_names = numerical_feature_names + categorical_feature_names

    # Create a DataFrame with the correct shape
    X = pd.DataFrame(processed_features, columns=feature_names)

    # Variable of interest
    y = data["Attendance (%)"]

    print("Data preprocessed successfully.")
    print("Processed Features:\n", X.head())
    print("Target Variable:\n", y.head())

    return X, y

if __name__ == "__main__":
    X, y = preprocess_data(r"C:\Users\PC\Desktop\Student Performance Prediction System\Students_Grading_Dataset.csv")
